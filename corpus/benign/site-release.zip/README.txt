Release notes for the sanitiser.
